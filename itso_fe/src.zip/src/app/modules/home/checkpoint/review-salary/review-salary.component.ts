import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-review-salary',
  templateUrl: './review-salary.component.html',
  styleUrls: ['./review-salary.component.scss']
})
export class ReviewSalaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
