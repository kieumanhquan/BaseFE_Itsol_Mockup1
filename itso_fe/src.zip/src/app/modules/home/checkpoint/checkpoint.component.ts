import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-checkpoint',
  templateUrl: './checkpoint.component.html',
  styleUrls: ['./checkpoint.component.scss'],
})
export class CheckpointComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
