export interface PasswordBean {
  passwordOld?: string;
  passwordNew?: string;
  confirmPassword?: string;
}
