import { Observable } from 'rxjs';

export interface User {
  name: string;
  picture: string;
}

