export interface Role{
  id: number ;
  code: string;
  description: string;
  delete: boolean;
}
